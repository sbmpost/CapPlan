use mysql;
insert into user (Host,User,Password,Process_priv)
values(SUBSTRING_INDEX(USER(),'@',-1),'postware',PASSWORD('postware'),'Y');
insert into db (Host,Db,User,Select_priv,Insert_priv,Update_priv,Delete_priv)
values(SUBSTRING_INDEX(USER(),'@',-1),'capplan','postware','Y','Y','Y','Y');
flush privileges;
