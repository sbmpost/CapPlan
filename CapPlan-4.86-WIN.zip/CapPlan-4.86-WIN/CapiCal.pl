#!/usr/bin/perl -w
# copyright by PostWare (S.B.M. Post)
# $Id: capical,v 1.1 2014/01/11 19:14:58 darseq Exp $
# This script allows one to connect to a microsoft sql
# server on a linux based system to access appointment
# data. This allows for employees to look up their own
# appointments using a mobile device for instance. The
# $login, $passw and default $schedule value should be
# set before using it. The script is called like this:
# CapiCal.pl?schedule=1&employee=1&appsdate=2011-08-03
use strict;
use Time::Piece;
use DBI; use CGI;
#use Sys::Syslog qw( :DEFAULT setlogsock);
#setlogsock('unix');
#openlog('capical','pid',$ENV{'USER'});

our $login = '<login>';
our $passw = '<passw>';

my $cgi = new CGI;
my $employee = $cgi->param('employee');
my $appsdate = $cgi->param('appsdate');
my $schedule = $cgi->param('schedule');
if($employee) {$employee =~ s/'/\\'/g;}
else {print_error("An employee id must be given\n");}
if($appsdate) {$appsdate =~ s/'/\\'/g;}
else {$appsdate = localtime->ymd;}
if($schedule) {$schedule =~ s/'/\\'/g;}
else {$schedule = 1;}

my $dbh = DBI->connect('dbi:Sybase:server=sqlexpress',$login,$passw,
	{PrintError => 0,RaiseError => 1,AutoCommit => 1}) or
	print_error("Can't connect to database $DBI::errstr\n");

my $sth = $dbh->prepare("select replace(convert(varchar,DATE_FROM,112),'-','')+'T'+".
	"replace(convert(varchar,DATE_FROM,108),':','') as DATE_FROM,replace(convert(".
	"varchar,DATE_UNTIL,112),'-','')+'T'+replace(convert(varchar,DATE_UNTIL,108),".
	"':','') as DATE_UNTIL,UUID,LASTNAME,ADDRESS+case when ".
	"ADDRESS='' then '' else ', ' end+POSTCODE+case when POSTCODE='' then '' else ".
	"', ' end+CITY as LOCATION,TELEPHONE,TELEPHONE2,INFOTEXT,CANCELLED from (apps ".
	"right join entries on apps.APP_ID=entries.APP_ID) left join personal on ".
	"apps.PERSONAL_ID=personal.PERSONAL_ID where (entries.EMPLOYEE_ID=$employee) ".
	"and DATE_FROM<DATEADD(month,1,'$appsdate') and DATE_UNTIL>DATEADD(month,-1,".
	"'$appsdate') order by EMPLOYEE_ID,DATE_FROM,DATE_UNTIL,CANCELLED desc");

if($sth->execute) {
	my $calendar_id = "CapPlan-$schedule-$employee";
	print "Content-type: application/calendar\n";
	print "Content-disposition: inline; filename=\"calendar.ics\"\n";
	print "Pragma: no-cache\n";
	print "Expires: 0\n\n"; 
	print "BEGIN:VCALENDAR\r\n";
	print "VERSION:2.0\r\n";
	print "PRODID:-//PostWare//CapPlan iCal Export//EN\r\n";
	print "METHOD:PUBLISH\r\n";
	print "CALSCALE:GREGORIAN\r\n";
	print "X-WR-RELCALID:$calendar_id\r\n";
	#print "X-WR-CALNAME:$calendar_id\r\n";

	while(my $row = $sth->fetchrow_hashref) {
		my $cancelled = $row->{'CANCELLED'};
		# if entry is blocked, cancelled is undefined
		if(defined $cancelled && $cancelled eq '0') {
			my $uid = $row->{'UUID'};
			my $sequence = time();
			my $date_stamp = localtime->strftime('%Y%m%dT%H%M%S');
			my $date_from = $row->{'DATE_FROM'};
			my $date_until = $row->{'DATE_UNTIL'};
			my $lastname = EscapeFoldStr($row->{'LASTNAME'});
			my $location = EscapeFoldStr($row->{'LOCATION'});
			my $telephone = $row->{'TELEPHONE'};
			#$telephone2 = $row->{'TELEPHONE2'};
			my $infotext = EscapeFoldStr($row->{'INFOTEXT'});

			print "BEGIN:VEVENT\r\n";
			print "UID:$uid\r\n";
			print "SEQUENCE:$sequence\r\n";
			print "ORGANIZER;CN=CapPlan:mailto:capplan\@companyname.nl\r\n";
			print "DTSTAMP;TZID=Europe/Amsterdam:$date_stamp\r\n";
			print "DTSTART;TZID=Europe/Amsterdam:$date_from\r\n";
			print "DTEND;TZID=Europe/Amsterdam:$date_until\r\n";
			print "SUMMARY:$lastname\r\n";
			print "LOCATION:$location\r\n";
			print "URL:tel://$telephone\r\n";
			print "DESCRIPTION:$infotext\r\n";
			print "END:VEVENT\r\n";
		}
	}
	print "END:VCALENDAR\r\n";
	$sth->finish;
}
$dbh->disconnect;

sub EscapeFoldStr {
	my $text = shift;
	$text =~ s/\\/\\\\/g;
	$text =~ s/;/\\;/g;
	$text =~ s/,/\\,/g;
	$text =~ s/\r//g;
	$text =~ s/\n//g;

	#Fold text
	my $str = ""; my $chars = length($text);
	for(my $line=0;$line < $chars/50;$line++) {
		if($line) {$str .= "\r\n ";}
		$str .= substr($text,$line*50,50);
	}
	return $str;
}

sub print_error {
	my $message = shift;
	print "Content-type: text/plain\n";
	print "Status: 400 Bad Request\n\n";
	if(!$message) {$message = 'Unknown error';}
	print "$message";
	die;
}
