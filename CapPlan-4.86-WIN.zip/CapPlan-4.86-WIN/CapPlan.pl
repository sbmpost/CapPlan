#!/usr/bin/perl -w
# copyright by PostWare (S.B.M. Post)
# $Id: capplan,v 1.10 2014/01/11 19:30:21 darseq Exp $
# This script allows one to connect to a microsoft sql
# server on a linux based system to access appointment
# data. This allows for employees to look up their own
# appointments using a mobile device for instance. The
# $login, $passw and default $schedule value should be
# set before using it. The script is called like this:
# CapPlan.pl?schedule=1&employee=1&appsdate=2011-08-03

use strict;
use Time::Piece;
use Time::Seconds;
use DBI; use CGI;
use CGI::Ajax;

our $login = <login>;
our $passw = <passw>;
my $cgi = new CGI;
my $pjx = new CGI::Ajax(
	'persons_func' => \&get_persons,
	'insert_func' => \&insert_app
);
print $pjx->build_html($cgi,\&Show_HTML);

sub Show_HTML {
my $html = <<END;
	<html>
	<head>
	<title>CapPlan Script</title>
	<script language="javascript">
    		function submit() {document.myform.submit();}
		function insert() {
			if(arguments[0].length) {
				if(parseInt(arguments[0])) {submit();}
				else {alert('Appointment overlaps');}
			} else {alert('Invalid input');}
		}
	</script>
	<style type="text/css">
		hr {height: 1px;}
		table {border: 1px solid #006; font-size: 14pt;}
		select {font-size: 14pt;}
		input {font-size: 14pt;}
	</style>
	</head>
	<body>
END
	my $employee = $cgi->param('employee');
	my $appsdate = $cgi->param('appsdate');
	my $schedule = $cgi->param('schedule');
	if($employee) {$employee =~ s/'/\\'/g;}
	if($appsdate) {$appsdate =~ s/'/\\'/g;}
	if($schedule) {$schedule =~ s/'/\\'/g;}
	else {$schedule = 1;}
$html .= <<END;
	<center>
	<table width=750px cellpadding=6 cellspacing=0>
	<tr><td colspan=5 style="height:10px"></td></tr>
	<tr>
	<form name="myform" action="capplan" method="get">
	<input type="hidden" name="schedule" value="$schedule">
	<td colspan=2><select name="employee" style="width:220px;" onchange="submit()">
END
	my $dbh = DBI->connect('dbi:Sybase:server=sqlexpress',$login,$passw,
		{PrintError => 0,RaiseError => 1,AutoCommit => 1}) or
		die "Can't connect to database $DBI::errstr\n";
	my $sth = $dbh->prepare("select personal.PERSONAL_ID,SCHEDULE_ID,".
		"LASTNAME,ADDRESS,CITY,TELEPHONE,TELEPHONE2,POSTCODE from personal,".
		"employees where personal.PERSONAL_ID=employees.PERSONAL_ID and ".
		"employees.SCHEDULE_ID=$schedule and (HIDDEN=0 or CREATED_BY=".
		"'$login') order by EMPLOYEE_ORDER");
	if($sth->execute) {
		while (my $row = $sth->fetchrow_hashref) {
			if(not $employee) {$employee = $row->{'PERSONAL_ID'};}
			if($employee eq $row->{'PERSONAL_ID'}) {
				$html .= '<option selected=1 value='.$row->{'PERSONAL_ID'}.
					'>'.$row->{'LASTNAME'}.'</option>';
			} else {
				$html .= '<option value='.$row->{'PERSONAL_ID'}.
					'>'.$row->{'LASTNAME'}.'</option>';
			}
		}
		$sth->finish;
	}
$html .= <<END;
	</select></td>
	<td colspan=2>
	<select name="appsdate" style="width:220px;" onchange="submit()">
END
	if(not $appsdate) {$appsdate = localtime->ymd;}
	my $incrdate = Time::Piece->strptime($appsdate,'%Y-%m-%d');
	for(my $day=0;$day < 7;$day++,$incrdate += ONE_DAY) {
		if($appsdate eq $incrdate->ymd) {
			$html .= '<option selected=1 value='.$incrdate->ymd.
				'>'.$incrdate->dmy.' ('.$incrdate->fullday.')</option>';
		} else {
			$html .= '<option value='.$incrdate->ymd.
				'>'.$incrdate->dmy.' ('.$incrdate->fullday.')</option>';
		}
	}
$html .= <<END;
	</select></td>
END
	$html .= '<td>Request :: '.localtime->hms.'</td>';
$html .= <<END;
	</form>
	</tr>
	<tr><td colspan=5><hr></td></tr>
       	<tr>
	<td><b>TIME</b></td>
	<td><b>PERSON</b></td>
	<td><b>ADDRESS</b></td>
	<td><b>CITY</b></td>
	<td><b>INFO</b></td>
	</tr>
	<tr><td colspan=5><hr></td></tr>
END
	$sth = $dbh->prepare("select CONVERT(VARCHAR(5),DATE_FROM,108) as TIME,".
		"LASTNAME,ADDRESS,CITY,INFOTEXT,CANCELLED from (apps right join ".
		"entries on apps.APP_ID=entries.APP_ID) left join personal on ".
		"apps.PERSONAL_ID=personal.PERSONAL_ID where (entries.EMPLOYEE_ID=".
		"$employee) and DATE_FROM<'$appsdate 18:00:00' and DATE_UNTIL>".
		"'$appsdate 09:00:00' order by EMPLOYEE_ID,DATE_FROM,DATE_UNTIL,".
		"CANCELLED desc");
	if($sth->execute) {
		while(my $row = $sth->fetchrow_hashref) {
			my $cancelled = $row->{'CANCELLED'};
			# if entry is blocked, cancelled is undefined
			if(defined $cancelled && $cancelled eq '0') {
				$html .= '<tr>';
				$html .= '<td>'.$row->{'TIME'}.'</td>';
				$html .= '<td>'.$row->{'LASTNAME'}.'</td>';
				$html .= '<td>'.$row->{'ADDRESS'}.'</td>';
				$html .= '<td>'.$row->{'CITY'}.'</td>';
				$html .= '<td>'.$row->{'INFOTEXT'}.'</td>';
				$html .= '</tr>';
				$html .= '<tr><td colspan=5><hr></td></tr>';
			}
		}
		$sth->finish;
	}
	$dbh->disconnect;
$html .= <<END;
	<tr> <td colspan=2> New appointment: </td> </tr>
	<tr>
	<td><select id="time" style="width:80px;">
END
	for(my $hour=9;$hour < 18;$hour++) {
		for(my $minute=0;$minute < 60;$minute += 30) {
			my $timestr = sprintf('%2d:%02d',$hour,$minute);
			$html .= '<option value='.$timestr.'>'.$timestr.'</option>';
		}
	}
$html .= <<END;
	</select></td>
	<td colspan=2>
	SEARCH:
	&nbsp;&nbsp;
	<input type="text" id="name" style="width:140px;"
		onchange="persons_func(['name'],['persons']);"
		onfocus="this.select()">
	</td>
	<td colspan=2>
	INFO:
	&nbsp;&nbsp;
	<input type="text" id="info" style="width:220px;"
		onfocus="this.select()"> 
	</td>
	<tr>
	<td colspan=3>
	<div id="persons">
END
	$html .= get_persons();
$html .= <<END;
	</div>
	</td>
	<td colspan=2>
	PASSW:
	&nbsp;&nbsp;
	<input type="text" id="password" style="width:80px;"
		onfocus="this.select()">
	&nbsp;&nbsp;
	<input type="button" style="width:80px"; value="Create" onclick=
		"insert_func(['employee','appsdate','per_id','time','info','password'],[insert]);">
	</td>
	</tr>
	</table>
	</center>
	</body>
	</html>
END
    	return $html;
}

sub get_persons {
	my $persons = '<select id="per_id" style="width:400px;">';
	my $lastname = shift; 
	if($lastname) {
		$lastname =~ s/'/\\'/g;
		my $dbh = DBI->connect('dbi:Sybase:server=sqlexpress',$login,$passw,
			{PrintError => 0,RaiseError => 1,AutoCommit => 1}) or
			die "Can't connect to database $DBI::errstr\n";
		my $sth = $dbh->prepare("select top 50 PERSONAL_ID,LASTNAME,ADDRESS,".
			"CITY from personal where LASTNAME like '%$lastname%' and ".
			"(HIDDEN=0 or CREATED_BY='$login') order by PERSONAL_ID desc");
		if($sth->execute) {
			while (my $row = $sth->fetchrow_hashref) {
				$persons .= '<option value=';
				$persons .= $row->{'PERSONAL_ID'}.'>';
				$persons .= $row->{'LASTNAME'}.' - ';
				$persons .= $row->{'ADDRESS'}.' - ';
				$persons .= $row->{'CITY'};
				$persons .= '</option>';
			}
			$sth->finish;
		}
	}
	$persons .= '</select>';
	return($persons);
}

sub insert_app {
	my $app_id;
	my $employee = shift;
	my $appsdate = shift;
	my $per_id = shift;
	my $time = shift;
	my $info = shift;
	my $password = shift;
	if($password) {$password =~ s/'/\\'/g;}
	my $dbh = DBI->connect('dbi:Sybase:server=sqlexpress',$login,$password,
		{PrintError => 0,RaiseError => 1,AutoCommit => 1}) or
		die "Can't connect to database $DBI::errstr\n";

	my $planned = 0;
	my $from = Time::Piece->strptime($appsdate.
		' '.$time,'%Y-%m-%d %H:%M');
	my $until = $from + 15*ONE_MINUTE;
	$from = $from->ymd.' '.$from->hms;
	$until = $until->ymd.' '.$until->hms;
	# Check for overlapping entries. Note that it would be better to do
	# this within a transaction to be absolutely sure no overlaps exist.
	my $sth = $dbh->prepare("select CANCELLED from apps right join entries ".
		"on apps.APP_ID=entries.APP_ID where EMPLOYEE_ID=$employee and ".
		"DATE_FROM<'$until' and DATE_UNTIL>'$from' order by EMPLOYEE_ID,".
		"DATE_FROM,DATE_UNTIL,CANCELLED desc");
	if($sth->execute) {
		while($planned == 0 && (my $row = $sth->fetchrow_hashref)) {
			my $cancelled = $row->{'CANCELLED'};
			if(not defined $cancelled) {$planned = 1;}
			else {$planned = $cancelled eq '0';}
		}
		$sth->finish;
	}
	if($planned == 1) {return 0;}

	$sth = $dbh->prepare("insert into apps (PERSONAL_ID,EXCLUSIVE,".
		"CANCELLED,PAID,COLOR,CHARGE,CREATED_DATE,CREATED_BY,INFOTEXT) ".
		"values($per_id,0,0,0,0,0,CURRENT_TIMESTAMP,'$login','$info')");
	if($sth->execute) {
		$sth->finish;
		$sth = $dbh->prepare("select \@\@IDENTITY as LAST_ID");
		if($sth->execute) {
			while (my $row = $sth->fetchrow_hashref) {
				$app_id = $row->{'LAST_ID'};
			}
			$sth->finish;
			$sth = $dbh->prepare("insert into entries ".
				"values($employee,'$from','$until',".
				"'1899-12-30 00:15:00',0,$app_id,".
				"NewId())");
			if($sth->execute) {$sth->finish;}
		} 
	} 
	return $app_id;
}
