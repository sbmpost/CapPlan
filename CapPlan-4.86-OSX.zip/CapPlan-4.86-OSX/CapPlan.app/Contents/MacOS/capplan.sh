#!/bin/sh

ROOT="$(cd "$(dirname "$0")" && pwd)"
RESOURCES="$ROOT/../Resources"

export WINEARCH="win64"
export WINEPREFIX="$RESOURCES/wine-prefix"
export PATH="$PATH:$RESOURCES/wine/bin"
export LC_ALL="en_US.UTF-8"

APP="$(winepath "c:\\users\\$USER\\CapPlan\\CapPlan.exe")"
cd "$(dirname "$APP")" && wine64 "$(basename "$APP")" &
