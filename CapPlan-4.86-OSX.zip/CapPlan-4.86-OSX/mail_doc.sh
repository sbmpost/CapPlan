#!/bin/bash
#/usr/local/bin/mail_doc.sh
#see also winebrowser.reg

if [ "$1" != "" ]; then
  open -a Mail "$1"
fi
